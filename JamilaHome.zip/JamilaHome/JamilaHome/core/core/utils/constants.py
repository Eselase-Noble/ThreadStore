from enum import Enum



DEFAULT_IMAGE_URL = 'https://www.ikea.com/gb/en/images/products/malm-bed-frame-high-black-brown-luroey__0638608_pe699032_s5.jpg?f=xl'

class StatusCodes(Enum):
    PUBLISHED = '1'
